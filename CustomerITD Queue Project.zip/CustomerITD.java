import LinkedQueue.*;
import java.util.*;

public class CustomerITD {

    public void menu(LinkedQueue<String>customerqueue, int Snum){

        Scanner in = new Scanner(System.in);

        System.out.println("\nQueue Operations :");
        System.out.println("1. Insert");
        System.out.println("2. Remove");
        System.out.println("3. Peek Front");
        System.out.println("4. Contains");
        System.out.println("5. Display the queue");
        System.out.println("6. Check Size");
        System.out.println("7. Is Empty");
        System.out.println("8. Exit");
        System.out.print("Enter Operation Number  that you would like to perform :  ");

        int selection = in.nextInt();
        in.nextLine();


        switch (selection){


            case 1:

                String firstName = input("Enter first name: ");
                String lastName = input("Enter last name: ");
                String serviceNumber = Integer.toString(Snum);
                customerqueue.enqueue(firstName, lastName, serviceNumber);
                System.out.println("Customer added to the queue.");
                break;

            case 2:
                try {
                    String removedCustomer = customerqueue.dequeue();
                    System.out.println(removedCustomer + " removed from the queue.");
                } catch (QueueUnderflowException e) {
                    System.out.println("Queue is empty.");
                }
                break;

            case 3:
                try {
                    System.out.println("First in queue :");
                    customerqueue.peekFront();
                } catch (QueueUnderflowException e) {
                    System.out.println("Queue is empty.");
                }
                break;

            case 4:
                String searchName = input("Enter first name or last name to search: ");
                boolean found = customerqueue.contains(searchName);
                if (!found) {
                    System.out.println("No matching customer found in the queue.");
                }
                break;

            case 5:
                customerqueue.display();
                break;

            case 6:
                System.out.println("Queue size: " + customerqueue.size());
                break;

            case 7:
                System.out.println("Is the queue empty? " + customerqueue.isEmpty());
                break;

            case 8:
                System.out.println("Exiting the program.");
                in.close();
                System.exit(0);
                break;



            default:
                System.out.println("Invalid choice. Please try again.");
        }
        try {
            // Sleep for 1000 milliseconds (1 second)
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // Handle the exception if it occurs
            e.printStackTrace();
        }
        Snum++;
        menu(customerqueue,Snum);

    }
    public static String input(String prompt) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(prompt);
        return scanner.nextLine();
    }


}