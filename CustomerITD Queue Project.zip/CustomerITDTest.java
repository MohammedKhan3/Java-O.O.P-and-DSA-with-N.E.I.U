/**
 *Name : Mohammed Fawzaan Khan
 * Date : 10/31/2023
 * Part 2 Of the project
 */

import LinkedQueue.*;
public class CustomerITDTest {
    public static void main(String[] args) {

        LinkedQueue<String> queue = new LinkedQueue<String>();
        CustomerITD new_customerItd = new CustomerITD();
        //Each time after running menu - thread stops for 2 seconds.
        new_customerItd.menu(queue,1000);
    }
}