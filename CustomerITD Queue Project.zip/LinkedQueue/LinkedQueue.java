package LinkedQueue;

public class LinkedQueue <T> {
    protected PersonNode<T> front;
    protected PersonNode<T> rear;
    protected int numElements;

    public LinkedQueue()
    {
        front = null;
        rear = null;
        numElements = 0;
    }

    public void enqueue(T fName, T lName, T sNum)
    {
        //Complete this method as required in the homework instructions.

        PersonNode<T> person = new PersonNode(fName,lName,sNum);
        if(isEmpty()){
            front = person;
            rear = person;
        }else{
            rear.link = person;
            rear = person;

        }
        numElements++;


    }


    public T dequeue()
    {
        if (isEmpty()) {
            throw new QueueUnderflowException("Queue is empty");
        }

        String data = front.getFirstName() + " " + front.getLastName() + ", " + front.getServiceNumber();

        front = front.link;
        numElements--;
        return (T) data;

    }

    public void peekFront()
    {
        //Complete this method as required in the homework instructions.
        if(isEmpty()){
            throw new QueueUnderflowException("Queue is empty ");
        }
        System.out.println(front.getFirstName() + " , " + front.getLastName() + ", " + front.getServiceNumber() );


    }

    public boolean contains(T lookFor)
    {
        PersonNode personNode = front;
        while (personNode!=null){
            if(personNode.getFirstName().equals(lookFor) || personNode.getLastName().equals(lookFor)){
                System.out.println(personNode.getFirstName() + " " + personNode.getLastName() + ", " + personNode.getServiceNumber());
                return true;
            }
            personNode = personNode.link;
        }

        return false;


    }

    public void display()
    {
        PersonNode current = front;
        while (current != null) {
            System.out.println(current.getFirstName() + " " + current.getLastName() + ", " + current.getServiceNumber());
            current = current.link;
        }
    }

    public int size()
    {
        return numElements;
    }

    public boolean isFull()
    {
        return false;
    }

    public boolean isEmpty()
    {
        return numElements == 0;
    }
}
