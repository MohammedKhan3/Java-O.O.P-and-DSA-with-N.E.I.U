import java.util.*;
import java.io.*;
public class MaximumOfEachLine {
    public static void main(String[] args) {

        readData("C:\\Users\\Owner\\Desktop\\data\\data\\data.txt");

    }

    public static void readData(String name) {

        try {
            File file = new File(name);
            Scanner readr = new Scanner(file);
            while (readr.hasNext()) {
             //   System.out.println(readr.nextLine());
                ArrayList<Integer>numbersArrayList = new ArrayList<>();
                String[]split = readr.nextLine().split(" ");
                String first_name = split[0];
                String last_name = split[1];
                String numberLine = split[2];
                String []numberArray=numberLine.split(",");
                for (int i = 0; i <numberArray.length ; i++) {
                   int temp = Integer.parseInt(numberArray[i]);
                   numbersArrayList.add(temp);
                }
                int max = numbersArrayList.get(0);
                for (int num : numbersArrayList) {
                    if (num > max) {
                        max = num;
                    }
                }

                System.out.println(first_name + " "+ last_name + " Max :" + max);
            }
        }catch (FileNotFoundException ex){
            System.out.println("File not Found!");
        }catch (Exception e){
            System.out.println("Exception!"+e.getStackTrace());
        }

    }//end of read data
}//end of main function

