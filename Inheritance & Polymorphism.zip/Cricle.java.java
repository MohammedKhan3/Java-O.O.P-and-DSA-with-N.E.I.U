/**
 *
 *
 */
import java.lang.Math.*;
public class Circle extends Shape {
    private double radius;
    public Circle(){
        this.radius = 1;
    }
    public Circle(double r){
        this.radius = r;
    }
    public Circle(double r, boolean filled,String color){
        super(filled,color);
        this.radius = r;
    }

    public double getArea(){
        double area = Math.PI*(this.radius*this.radius);
        return area;
    }
    @Override
    public String toString(){
        String variables = "Radius : " + this.radius + "\nArea : " + getArea() +"\n" + super.toString();
        return variables;
    }



}
