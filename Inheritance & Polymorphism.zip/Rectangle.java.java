import java.lang.IllegalAccessException;
public class Rectangle extends Shape{
    private double width,length;

    public Rectangle(){
        this.length =2;
        this.width =1;
    }
    public Rectangle( double l, double w)  {
        setLW(l,w);
    }
    public Rectangle( double l, double w, boolean filled, String color){
        super(filled,color);
        setLW(l,w);

    }
    public void setLW(double x,double y) {
        if(x>y){
            this.length = x;
            this.width = y;
        }else{
            this.length = y;
            this.width = x;
        }

    }

    public double getArea(){
        return this.width * this.length;
    }
    @Override
    public String toString(){
        String variables = "Width : " + this.width + "\nLength : " + this.length + "\nArea : " +  getArea() +"\n" + super.toString();
        return variables;
    }

}
