import java.util.*;
public class Sentence {
    private String sentence;

    public Sentence() {

    }

    public Sentence(String sentence) {
        this.sentence = sentence;
    }

    public String getSentence() {
        return this.sentence;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        Sentence otherSentence = (Sentence) object;
        return Objects.equals(sentence, otherSentence.sentence);
    }

}
