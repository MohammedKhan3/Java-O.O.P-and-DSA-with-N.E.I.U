/*
Name : Mohammed Khan
Date : 10/24/2023
Homework - 7


 */

import java.util.Scanner;


public class RecursiveMethods {
    public static void main(String[] args) {
        int[] arr = {2, 4, 6, 8};
        int[] arr2 = {1, 2, 3, 4, 5};
        int[] arr3 = {2, 4};
        System.out.println();
        System.out.println("-------------");
        System.out.println("Testing oddEvenMatchRec with arr - {2, 4, 6, 8}");
        System.out.println(oddEvenMatchRec(arr, 0, false));
        System.out.println();
        System.out.println("-------------");
        System.out.println("Testing oddEvenMatchRec with arr - {1, 2, 3, 4, 5}");
        System.out.println(oddEvenMatchRec(arr2, 0, false));
        System.out.println();
        System.out.println("-------------");
        System.out.println("Testing sumNRec with arr - {2, 4}");
        System.out.println(sumNRec(arr3, 0));
        System.out.println();
        System.out.println("-------------");
        System.out.println("Testing nDownToOne with parameter 5 ");
        System.out.println(nDownToOne(5));
        System.out.println();
        System.out.println("-------------");
        System.out.println("Testing inputAndPrintReverse");
        inputAndPrintReverse();

    }//end of main

    public static boolean oddEvenMatchRec(int[] arr, int start, boolean isstartOdd) {
        if (start == arr.length) {
            System.out.println("All elements have been scanned!");
            return true;
        }
        boolean isElementeven = arr[start] % 2 == 0;
        boolean isIndexodd = start % 2 == 0;
        if (isElementeven && isIndexodd) {

            oddEvenMatchRec(arr, start + 1, true);
            return true;
        }

        if (!isElementeven && !isIndexodd) {

            oddEvenMatchRec(arr, start + 1, false);
            return true;
        }

        return false;

    }
//sumNRec: The method takes an integer array A and returns the sum of all
//integers in the parameter array.

    public static int sumNRec(int [] arr,int i){


        if(i== arr.length){
            System.out.println("All elements have been added!");
            return 0;
        }
        return arr[i] + sumNRec(arr,i+1);
    }
    //nDownToOne: Takes an integer n and prints out the numbers from n down
    //to 1, each number on its own line

    public static int nDownToOne(int n){
        if(n>1){
            System.out.println(n);
            nDownToOne(n-1);
        }
        return 1;
    }

    /*

    inputAndPrintReverse: Inputs integers from the user until the user
enters 0, then prints the integers in reverse order. For this method, you
may NOT use an array or any type of array structure, in other words, you
may not use any structure to store the user input
     */
public static void inputAndPrintReverse(){
    Scanner keyboard = new Scanner(System.in);
    System.out.println("Enter a number : ");
    int number = keyboard.nextInt();
    if(number!=0){
        inputAndPrintReverse();
    }

    System.out.println(number);
  }

}// end of MAIN
